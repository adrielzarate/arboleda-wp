<!-- ONE COLUMN SECTION -->
<table border="0" cellpadding="0" cellspacing="0" width="100%" class="tnpc-row" data-id="content-02">
    <tr>
        <td bgcolor="#ffffff" align="center" style="padding: 15px; font-family: Helvetica, Arial, sans-serif;" class="section-padding edit-block">
            <table border="0" cellpadding="0" cellspacing="0" width="500" class="responsive-table" style="max-width: 100%!important">
                <tr>
                    <td align="center" style="font-size: 25px; color: #333333; padding-top: 30px;" class="padding-copy tnpc-row-edit" data-type="title">An Awesome Title</td>
                </tr>
            </table>
        </td>
    </tr>
</table>