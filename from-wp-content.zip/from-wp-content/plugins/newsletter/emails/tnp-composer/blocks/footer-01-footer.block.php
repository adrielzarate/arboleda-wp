<!-- FOOTER -->
<table border="0" cellpadding="0" cellspacing="0" width="100%" class="tnpc-row" data-id="footer-01">
    <tr>
        <td bgcolor="#ffffff" align="center" style="padding: 20px 0px;" class="edit-block">
            <!-- UNSUBSCRIBE COPY -->
            <table width="500" border="0" cellspacing="0" cellpadding="0" align="center" class="responsive-table">
                <tr>
                    <td align="center" style="font-size: 12px; line-height: 18px; font-family: Helvetica, Arial, sans-serif; color:#666666;">
                        <div class="tnpc-row-edit" data-type="text" style="color:#666666;"><?php echo isset($block_options['footer_title']) ? $block_options['footer_title'] : 'Your Company' ?><br/>
                            <?php echo isset($block_options['footer_contact']) ? $block_options['footer_contact'] : 'Company Address, Phone Number' ?><br/>
                            <em><?php echo isset($block_options['footer_legal']) ? $block_options['footer_legal'] : 'Copyright or Legal text' ?></em>
                        </div>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
