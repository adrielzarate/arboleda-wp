<!-- ONE COLUMN SECTION -->
<table border="0" cellpadding="0" cellspacing="0" width="100%" class="tnpc-row" data-id="content-03">
    <tr>
        <td bgcolor="#ffffff" align="center" style="padding: 20px 15px 20px 15px; font-family: Helvetica, Arial, sans-serif;" class="section-padding edit-block">
            <table border="0" cellpadding="0" cellspacing="0" class="responsive-table" style="width: 100%!important">
                <tr>
                    <td align="center" style="padding: 0 0 0 0; font-size: 16px; line-height: 25px; color: #666666;" class="padding-copy tnpc-row-edit" data-type="text">The judge, by the way, was the King; and as he wore his crown over the wig, (look at the frontispiece if you want to see how he did it,) he did not look at all comfortable, and it was certainly not becoming.</td>
                </tr>
            </table>
        </td>
    </tr>
</table>