<!-- HEADER -->
<table border="0" cellpadding="0" cellspacing="0" width="100%" data-id="header-01" class="tnpc-row" data-id="header-01">
    <tr>
        <td bgcolor="#333333" class="edit-block">
            <div align="center" style="padding: 0px 15px 0px 15px;">
                <table border="0" cellpadding="0" cellspacing="0" width="500" class="wrapper">
                    <!-- LOGO/PREHEADER TEXT -->
                    <tr>
                        <td style="padding: 20px 0px 30px 0px;" class="logo">
                            <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                <tr>
                                    <td width="100" align="left" class="tnpc-row-edit" data-type="image">
                                        <a href="#" target="_blank">
                                            <img alt="Logo" src="<?php echo isset($block_options['header_logo']) ? $block_options['header_logo']['url'] : 'http://placehold.it/180x50?text=' . isset($block_options['header_title']) ? $block_options['header_title'] : "" ?>" style="display: block; width: 180px; font-family: Helvetica, Arial, sans-serif; color: #ffffff; font-size: 16px;" border="0">
                                        </a>
                                    </td>
                                    <td width="400" align="right" class="mobile-hide">
                                        <table border="0" cellpadding="0" cellspacing="0">
                                            <tr>
                                                <td align="right" style="padding: 0 0 5px 0; font-size: 14px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;" class="tnpc-row-edit" data-type="text">
                                                    <span style="color: #666666; text-decoration: none;" ><?php echo isset($block_options['header_sub']) ? $block_options['header_sub'] : 'A little text up top can be nice.<br>Maybe a link to tweet?' ?></span>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </div>
        </td>
    </tr>
</table>