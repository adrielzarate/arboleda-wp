WordPress Geolocator
==========

[![Latest Release](https://img.shields.io/github/release/masikonis/wordpress-geolocator.svg)](https://github.com/masikonis/wordpress-geolocator/releases)

Geolocator plugin for WordPress.

Official page: [https://wordpress.org/plugins/geolocator/](https://wordpress.org/plugins/geolocator/)